// to start sql in terminal use ---
// cd "C:\Program Files\MySQL\MySQL Server 8.0"  
// & .\bin\mysql.exe -h localhost -u root -p


const { faker } = require('@faker-js/faker');
const mysql=require("mysql2");

// const connection = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     database: 'delta_app',
//     password:'mysql@123'
//   });

//   try{
//     connection.query("SHOW TABLES",(err,result)=>{
//         if(err) throw err;
//         console.log(result);
//      });
//   }catch(err){
//      console.log(err);
//   }
//   connection.end();
  let createRandomUser=()=>{
    return {
      id: faker.string.uuid(),
      username: faker.internet.userName(),
      email: faker.internet.email(),
      password: faker.internet.password()
    };
  };
//   console.log(createRandomUser());
